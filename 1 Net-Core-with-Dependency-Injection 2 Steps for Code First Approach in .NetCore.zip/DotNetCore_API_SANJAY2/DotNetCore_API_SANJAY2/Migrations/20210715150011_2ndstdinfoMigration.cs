﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DotNetCore_API_SANJAY2.Migrations
{
    public partial class _2ndstdinfoMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "studentinfo2",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StuName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StuFathersName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StuEmail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StuAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StuPhone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StuAge = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StuClass = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_studentinfo2", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "studentinfo2");
        }
    }
}
