﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetCore_API_SANJAY2.Models
{
    public class ApiDbContext : DbContext  // (DbContext is abstract base class)
    {
        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options) // parameterised constructor (ApiDbContext this is class name.)(options is variable name.)
        {
            
        }
        public DbSet<Student> studentinfo2 { get; set; } // this is models name <Student> and studentDto is a table. we will call by studentDto.

    }
}
