﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DotNetCore_API_SANJAY2.Models
{
    public class Student
    {
        [Key]
        public int ID { get; set; }
        public string StuName { get; set; }
        public string StuFathersName { get; set; }
        public string StuEmail { get; set; }
        public string StuAddress { get; set; }
        public string StuPhone { get; set; }
        public string StuAge{ get; set; }
        public string StuClass { get; set; }
       
    }
}
