﻿using DotNetCore_API_SANJAY2.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetCore_API_SANJAY2.Services
{
    public class Student : IStudent
    {
        public string GetStuName()
        {
            return "Hi this is Sanjay practice 2";
        }
    }
}
