﻿using IntroToDI.Interface;
using IntroToDI.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IntroToDI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {

        private readonly IStudent student;
        private readonly IParent parent;

        public StudentController(IStudent _student,IParent _parent)
        {
            student = _student;
            parent = _parent;
        }


        [HttpGet]
        public string GetName()
        {
            Student stu = new Student();
            string name2 = stu.PrintStudentName();


            string stuName = student.PrintStudentName();
            string parentName = parent.PrintName();
            string message = "Student name is : " + stuName + " & Parent Name is : " + parentName;
            return message;
        }
    }
}
