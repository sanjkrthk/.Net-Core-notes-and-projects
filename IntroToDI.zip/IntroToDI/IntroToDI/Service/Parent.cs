﻿using IntroToDI.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IntroToDI.Service
{
    public class Parent : IParent
    {
        public string PrintName()
        {
            return "Parent of Student";
        }
    }
}
